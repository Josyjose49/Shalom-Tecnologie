function Home() {
    try {
        const featuredArticle = {
            title: "O Futuro da Inteligência Artificial: Como a IA está Transformando o Mundo",
            excerpt: "Uma análise profunda sobre como a inteligência artificial está revolucionando diversos setores e mudando a forma como vivemos e trabalhamos.",
            category: "Tecnologia",
            image: "https://source.unsplash.com/random/1920x1080/?artificial-intelligence"
        };

        const recentNews = [
            {
                title: "5G: A Nova Era da Conectividade",
                excerpt: "Descubra como a tecnologia 5G está revolucionando a comunicação e criando novas possibilidades.",
                category: "Tecnologia",
                date: "2024-01-20",
                image: "https://source.unsplash.com/random/800x600/?5g-technology"
            },
            {
                title: "Criptomoedas: O Futuro do Dinheiro Digital",
                excerpt: "Uma análise sobre o impacto das criptomoedas na economia global e suas perspectivas futuras.",
                category: "Economia",
                date: "2024-01-19",
                image: "https://source.unsplash.com/random/800x600/?cryptocurrency"
            },
            {
                title: "Sustentabilidade na Tecnologia",
                excerpt: "Como as empresas de tecnologia estão contribuindo para um futuro mais sustentável.",
                category: "Tecnologia",
                date: "2024-01-18",
                image: "https://source.unsplash.com/random/800x600/?sustainable-technology"
            }
        ];

        const technologyArticles = [
            {
                title: "O Impacto da Inteligência Artificial no Trabalho",
                excerpt: "Como a IA está mudando o mercado de trabalho e criando novas oportunidades.",
                category: "Tecnologia",
                date: "2024-01-20",
                image: "https://source.unsplash.com/random/800x600/?ai-robot",
                author: {
                    name: "Ana Silva",
                    avatar: "https://source.unsplash.com/random/100x100/?portrait,1"
                }
            },
            {
                title: "Realidade Virtual: O Futuro do Entretenimento",
                excerpt: "Explorando as últimas inovações em realidade virtual e suas aplicações.",
                category: "Tecnologia",
                date: "2024-01-19",
                image: "https://source.unsplash.com/random/800x600/?virtual-reality",
                author: {
                    name: "Pedro Santos",
                    avatar: "https://source.unsplash.com/random/100x100/?portrait,2"
                }
            },
            {
                title: "Cibersegurança em 2024",
                excerpt: "As principais tendências e desafios da segurança digital este ano.",
                category: "Tecnologia",
                date: "2024-01-18",
                image: "https://source.unsplash.com/random/800x600/?cybersecurity",
                author: {
                    name: "Carlos Oliveira",
                    avatar: "https://source.unsplash.com/random/100x100/?portrait,3"
                }
            }
        ];

        const economyArticles = [
            {
                title: "Mercado Digital em Transformação",
                excerpt: "As principais mudanças no cenário econômico digital global.",
                category: "Economia",
                date: "2024-01-20",
                image: "https://source.unsplash.com/random/800x600/?digital-market",
                author: {
                    name: "Mariana Costa",
                    avatar: "https://source.unsplash.com/random/100x100/?portrait,4"
                }
            },
            {
                title: "Startups: O Novo Motor da Economia",
                excerpt: "Como as startups estão impulsionando a inovação e o crescimento econômico.",
                category: "Economia",
                date: "2024-01-19",
                image: "https://source.unsplash.com/random/800x600/?startup",
                author: {
                    name: "Ricardo Lima",
                    avatar: "https://source.unsplash.com/random/100x100/?portrait,5"
                }
            },
            {
                title: "Investimentos em Tecnologia",
                excerpt: "Os setores tecnológicos que mais atraem investimentos em 2024.",
                category: "Economia",
                date: "2024-01-18",
                image: "https://source.unsplash.com/random/800x600/?investment",
                author: {
                    name: "Júlia Mendes",
                    avatar: "https://source.unsplash.com/random/100x100/?portrait,6"
                }
            }
        ];

        return (
            <div data-name="home-page">
                <Header />
                <Navigation />
                <FeaturedNews article={featuredArticle} />
                
                <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                    <section data-name="recent-news" className="mb-16">
                        <h2 className="text-3xl font-bold mb-8">Notícias Recentes</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                            {recentNews.map((article, index) => (
                                <NewsCard key={index} article={article} />
                            ))}
                        </div>
                    </section>

                    <CategorySection 
                        title="Tecnologia" 
                        articles={technologyArticles} 
                    />
                    
                    <CategorySection 
                        title="Economia" 
                        articles={economyArticles} 
                    />
                </main>

                <Newsletter />
                <Footer />
            </div>
        );
    } catch (error) {
        console.error('Home page error:', error);
        reportError(error);
        return null;
    }
}
