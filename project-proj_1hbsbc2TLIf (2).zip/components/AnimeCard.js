function AnimeCard({ title, image, rating, episodes }) {
    try {
        return (
            <div data-name="anime-card" className="anime-card bg-white rounded-lg shadow-lg overflow-hidden">
                <img data-name="anime-image" src={image} alt={title} className="w-full h-48 object-cover"/>
                <div className="p-4">
                    <h3 data-name="anime-title" className="text-lg font-semibold mb-2">{title}</h3>
                    <div className="flex justify-between items-center">
                        <span data-name="anime-rating" className="text-yellow-500">
                            <i className="fas fa-star"></i> {rating}
                        </span>
                        <span data-name="anime-episodes" className="text-gray-600">
                            {episodes} Episodes
                        </span>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('AnimeCard error:', error);
        reportError(error);
        return null;
    }
}
