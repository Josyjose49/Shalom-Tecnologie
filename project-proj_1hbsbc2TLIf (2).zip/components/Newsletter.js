function Newsletter() {
    try {
        const [email, setEmail] = React.useState('');

        const handleSubmit = (e) => {
            e.preventDefault();
            // Handle newsletter subscription
            console.log('Newsletter subscription:', email);
            setEmail('');
        };

        return (
            <section data-name="newsletter" className="newsletter-box text-white py-16">
                <div className="max-w-4xl mx-auto px-4 text-center">
                    <h2 className="text-3xl font-bold mb-4" data-name="newsletter-title">
                        Fique por dentro das últimas novidades
                    </h2>
                    <p className="mb-8" data-name="newsletter-description">
                        Assine nossa newsletter e receba as notícias mais importantes diretamente em seu e-mail.
                    </p>
                    <form onSubmit={handleSubmit} className="flex max-w-md mx-auto">
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="Seu endereço de e-mail"
                            className="flex-1 px-4 py-3 rounded-l-lg text-gray-900"
                            required
                            data-name="email-input"
                        />
                        <button 
                            type="submit" 
                            className="bg-white text-primary px-6 py-3 font-semibold rounded-r-lg hover:bg-gray-100"
                            data-name="subscribe-btn"
                        >
                            Assinar
                        </button>
                    </form>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Newsletter error:', error);
        reportError(error);
        return null;
    }
}
