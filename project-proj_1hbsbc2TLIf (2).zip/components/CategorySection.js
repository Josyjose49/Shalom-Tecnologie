function CategorySection({ title, articles }) {
    try {
        return (
            <section data-name="category-section" className="py-12">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between items-center mb-8">
                        <h2 data-name="category-title" className="text-2xl font-bold text-gray-900">{title}</h2>
                        <a 
                            href="#" 
                            className="text-primary hover:text-blue-700 flex items-center"
                            data-name="view-all-link"
                        >
                            Ver Tudo
                            <i className="fas fa-arrow-right ml-2"></i>
                        </a>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {articles.map((article, index) => (
                            <article 
                                key={index} 
                                className="bg-white rounded-lg shadow-lg overflow-hidden"
                                data-name="category-article"
                            >
                                <img 
                                    src={article.image} 
                                    alt={article.title}
                                    className="w-full h-48 object-cover"
                                    data-name="article-image"
                                />
                                <div className="p-6">
                                    <div className="flex items-center mb-3">
                                        <span 
                                            className="text-sm text-gray-500"
                                            data-name="article-date"
                                        >
                                            {article.date}
                                        </span>
                                        <span className="mx-2">•</span>
                                        <span 
                                            className="text-sm text-primary"
                                            data-name="article-category"
                                        >
                                            {article.category}
                                        </span>
                                    </div>
                                    <h3 
                                        className="text-xl font-bold mb-3"
                                        data-name="article-title"
                                    >
                                        {article.title}
                                    </h3>
                                    <p 
                                        className="text-gray-600 mb-4"
                                        data-name="article-excerpt"
                                    >
                                        {article.excerpt}
                                    </p>
                                    <div className="flex items-center justify-between">
                                        <div 
                                            className="flex items-center"
                                            data-name="article-author"
                                        >
                                            <img 
                                                src={article.author.avatar} 
                                                alt={article.author.name}
                                                className="w-8 h-8 rounded-full mr-2"
                                            />
                                            <span className="text-sm text-gray-600">
                                                {article.author.name}
                                            </span>
                                        </div>
                                        <button 
                                            className="text-primary hover:text-blue-700"
                                            data-name="read-more-btn"
                                        >
                                            Ler Mais →
                                        </button>
                                    </div>
                                </div>
                            </article>
                        ))}
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('CategorySection error:', error);
        reportError(error);
        return null;
    }
}
