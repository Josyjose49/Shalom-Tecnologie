function Navigation() {
    try {
        return (
            <nav data-name="main-nav" className="bg-white border-b">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-center space-x-8 py-4">
                        <a href="#" className="nav-link text-gray-600 hover:text-primary" data-name="nav-home">Início</a>
                        <a href="#" className="nav-link text-gray-600 hover:text-primary" data-name="nav-news">Notícias</a>
                        <a href="#" className="nav-link text-gray-600 hover:text-primary" data-name="nav-politics">Política</a>
                        <a href="#" className="nav-link text-gray-600 hover:text-primary" data-name="nav-economy">Economia</a>
                        <a href="#" className="nav-link text-gray-600 hover:text-primary" data-name="nav-culture">Cultura</a>
                        <a href="#" className="nav-link text-gray-600 hover:text-primary" data-name="nav-tech">Tecnologia</a>
                        <a href="#" className="nav-link text-gray-600 hover:text-primary" data-name="nav-opinion">Opinião</a>
                        <a href="#" className="nav-link text-gray-600 hover:text-primary" data-name="nav-about">Sobre</a>
                        <a href="#" className="nav-link text-gray-600 hover:text-primary" data-name="nav-contact">Contacto</a>
                    </div>
                </div>
            </nav>
        );
    } catch (error) {
        console.error('Navigation error:', error);
        reportError(error);
        return null;
    }
}
