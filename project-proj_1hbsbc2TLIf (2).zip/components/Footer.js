function Footer() {
    try {
        return (
            <footer data-name="footer" className="bg-gray-900 text-white py-12">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                        <div>
                            <h4 data-name="footer-brand" className="text-xl font-bold mb-4">Shalom Tecnologie</h4>
                            <p className="text-gray-400">Seu portal de notícias tecnológicas</p>
                        </div>
                        <div>
                            <h4 data-name="footer-sections" className="text-xl font-bold mb-4">Seções</h4>
                            <ul className="space-y-2">
                                <li><a href="#" className="text-gray-400 hover:text-white">Notícias</a></li>
                                <li><a href="#" className="text-gray-400 hover:text-white">Tecnologia</a></li>
                                <li><a href="#" className="text-gray-400 hover:text-white">Opinião</a></li>
                            </ul>
                        </div>
                        <div>
                            <h4 data-name="footer-about" className="text-xl font-bold mb-4">Sobre</h4>
                            <ul className="space-y-2">
                                <li><a href="#" className="text-gray-400 hover:text-white">Quem Somos</a></li>
                                <li><a href="#" className="text-gray-400 hover:text-white">Contacto</a></li>
                                <li><a href="#" className="text-gray-400 hover:text-white">Política de Privacidade</a></li>
                            </ul>
                        </div>
                        <div>
                            <h4 data-name="footer-social" className="text-xl font-bold mb-4">Redes Sociais</h4>
                            <div className="flex space-x-4">
                                <a href="#" className="text-gray-400 hover:text-white text-2xl">
                                    <i className="fab fa-facebook"></i>
                                </a>
                                <a href="#" className="text-gray-400 hover:text-white text-2xl">
                                    <i className="fab fa-twitter"></i>
                                </a>
                                <a href="#" className="text-gray-400 hover:text-white text-2xl">
                                    <i className="fab fa-instagram"></i>
                                </a>
                                <a href="#" className="text-gray-400 hover:text-white text-2xl">
                                    <i className="fab fa-linkedin"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        );
    } catch (error) {
        console.error('Footer error:', error);
        reportError(error);
        return null;
    }
}
