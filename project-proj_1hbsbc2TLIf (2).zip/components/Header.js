function Header() {
    try {
        return (
            <header data-name="header" className="bg-white shadow-md">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                    <div className="flex items-center justify-between">
                        <a href="/" className="flex items-center space-x-3" data-name="logo">
                            <i className="fas fa-microchip text-4xl text-primary"></i>
                            <span className="text-2xl font-bold text-primary">Shalom Tecnologie</span>
                        </a>
                        <div className="flex items-center space-x-4">
                            <div className="hidden md:flex space-x-2">
                                <a href="#" className="btn-outline" data-name="discover-btn">Descobrir</a>
                                <a href="#" className="btn-primary" data-name="learn-more-btn">Saber Mais</a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
        );
    } catch (error) {
        console.error('Header error:', error);
        reportError(error);
        return null;
    }
}
