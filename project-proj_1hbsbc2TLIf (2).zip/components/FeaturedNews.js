function FeaturedNews({ article }) {
    try {
        return (
            <div data-name="featured-news" className="relative h-[500px] bg-gray-900">
                <img 
                    src={article.image} 
                    alt={article.title}
                    className="w-full h-full object-cover"
                    data-name="featured-image"
                />
                <div className="absolute inset-0 featured-gradient"></div>
                <div className="absolute bottom-0 left-0 right-0 p-8">
                    <div className="max-w-3xl mx-auto">
                        <span className="text-white bg-primary px-4 py-1 rounded-full text-sm" data-name="featured-category">
                            {article.category}
                        </span>
                        <h1 className="text-4xl font-bold text-white mt-4 mb-2" data-name="featured-title">
                            {article.title}
                        </h1>
                        <p className="text-gray-200 mb-4" data-name="featured-excerpt">
                            {article.excerpt}
                        </p>
                        <button className="btn-primary" data-name="read-more-btn">
                            Ler Mais
                        </button>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('FeaturedNews error:', error);
        reportError(error);
        return null;
    }
}
