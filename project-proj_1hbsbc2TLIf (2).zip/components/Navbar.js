function Navbar() {
    try {
        return (
            <nav data-name="navbar" className="bg-white shadow-lg">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between h-16">
                        <div className="flex items-center">
                            <a href="/" className="flex items-center" data-name="logo">
                                <i className="fas fa-play-circle text-3xl text-primary mr-2"></i>
                                <span className="text-2xl font-bold text-primary">AnimeMax</span>
                            </a>
                        </div>
                        <div className="flex items-center space-x-4">
                            <a href="#" data-name="nav-browse" className="text-gray-700 hover:text-primary px-3 py-2">Browse</a>
                            <a href="#" data-name="nav-pricing" className="text-gray-700 hover:text-primary px-3 py-2">Pricing</a>
                            <button data-name="nav-login" className="btn-primary">Login</button>
                        </div>
                    </div>
                </div>
            </nav>
        );
    } catch (error) {
        console.error('Navbar error:', error);
        reportError(error);
        return null;
    }
}
