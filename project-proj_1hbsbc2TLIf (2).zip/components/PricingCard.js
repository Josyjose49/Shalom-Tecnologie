function PricingCard({ tier, price, features }) {
    try {
        return (
            <div data-name="pricing-card" className="pricing-card bg-white rounded-lg p-6 text-center">
                <h3 data-name="pricing-tier" className="text-2xl font-bold text-primary mb-4">{tier}</h3>
                <div data-name="pricing-price" className="text-4xl font-bold mb-6">${price}<span className="text-gray-500 text-base">/month</span></div>
                <ul className="space-y-3 mb-6">
                    {features.map((feature, index) => (
                        <li data-name="pricing-feature" key={index} className="flex items-center justify-center">
                            <i className="fas fa-check text-green-500 mr-2"></i>
                            {feature}
                        </li>
                    ))}
                </ul>
                <button data-name="pricing-cta" className="btn-primary w-full">Choose Plan</button>
            </div>
        );
    } catch (error) {
        console.error('PricingCard error:', error);
        reportError(error);
        return null;
    }
}
