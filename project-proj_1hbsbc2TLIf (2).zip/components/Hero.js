function Hero() {
    try {
        return (
            <div data-name="hero" className="hero-gradient text-white py-20">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center">
                        <h1 data-name="hero-title" className="text-4xl md:text-6xl font-bold mb-6">
                            Your Premium Anime Destination
                        </h1>
                        <p data-name="hero-subtitle" className="text-xl md:text-2xl mb-8">
                            Watch exclusive anime content and support your favorite creators
                        </p>
                        <button data-name="hero-cta" className="bg-white text-primary px-8 py-3 rounded-lg font-bold text-lg hover:bg-gray-100 transition-colors">
                            Start Watching Now
                        </button>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('Hero error:', error);
        reportError(error);
        return null;
    }
}
