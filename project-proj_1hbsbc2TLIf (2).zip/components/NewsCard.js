function NewsCard({ article }) {
    try {
        return (
            <div data-name="news-card" className="news-card bg-white rounded-lg shadow-lg overflow-hidden">
                <img 
                    src={article.image} 
                    alt={article.title} 
                    className="w-full h-48 object-cover"
                    data-name="article-image"
                />
                <div className="p-6">
                    <span className="text-primary text-sm font-semibold" data-name="article-category">
                        {article.category}
                    </span>
                    <h3 className="text-xl font-bold mt-2 mb-3" data-name="article-title">
                        {article.title}
                    </h3>
                    <p className="text-gray-600 mb-4" data-name="article-excerpt">
                        {article.excerpt}
                    </p>
                    <div className="flex justify-between items-center">
                        <span className="text-gray-500 text-sm" data-name="article-date">
                            {article.date}
                        </span>
                        <button className="text-primary hover:underline" data-name="read-more-btn">
                            Ler Mais →
                        </button>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('NewsCard error:', error);
        reportError(error);
        return null;
    }
}
